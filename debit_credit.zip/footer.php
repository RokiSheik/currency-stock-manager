<!-- footer.php -->
</div>
<footer class="mt-8 p-4 text-center text-sm text-gray-500">&copy; <?= date('Y') ?> Currency Stock Manager</footer>
</body>

</html>